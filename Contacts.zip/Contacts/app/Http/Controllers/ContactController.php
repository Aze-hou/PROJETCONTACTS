<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contact;
use Validator;
use DB;


class ContactController extends Controller
{


//Récuperer tous les contacts : 
    public function pageAccueil(){
    	$contacts = Contact::all(); 
        $contacts = DB::table('contacts')->simplePaginate(7);
    	return view('PageAccueil',['LesContacts'=> $contacts]); 
    }
    
    public function AjoutContact(){
    	return view('AjouterContact'); 
    }

// SEARCH FOR CONTACT
    public function search(Request $request){
        $contacts = Contact::all(); 
         $search_text = $request->get('rechercher'); 
         $contacts = Contact::where('prenom','LIKE','%'.$search_text.'%')->orWhere('nom','LIKE','%'.$search_text.'%')->orWhere('ville','LIKE','%'.$search_text.'%')->orWhere('societe','LIKE','%'.$search_text.'%')->orWhere('email','LIKE','%'.$search_text.'%')->orWhere('civilite','LIKE','%'.$search_text.'%')->orWhere('telephone','LIKE','%'.$search_text.'%')->simplePaginate(7);
  

        return view('PageAccueil',['LesContacts'=> $contacts]); 

    }

// SAVE IN DATABASE
    
    public function submitData(Request $req){

        $civilite  =  $req->input('civilite');
        $prenom    =  $req->input('prenom');
        $nom       =  $req->input('nom');
        $fonction  =  $req->input('fonction');
        $service   =  $req->input('service');
        $telephone =  $req->input('telephone');
        $email     =  $req->input('email');
        $societe   =  $req->input('societe');

        $adresseSociete      =  $req->input('adresseSociete');
        $codePostale         =  $req->input('codePostale');
        $telephoneSociete    =  $req->input('telephoneSociete');
        $siteWebSociete      =  $req->input('siteWebSociete');
        $ville               =  $req->input('ville');


        $data = array('civilite' =>$civilite,'prenom' =>$prenom,'nom' =>$nom,'fonction' =>$fonction,'service' =>$service,'telephone' =>$telephone,'email' =>$email,'societe' =>$societe,'adresseSociete' =>$adresseSociete,'codePostale' =>$codePostale,'telephoneSociete' =>$telephoneSociete,'siteWebSociete' =>$siteWebSociete,'ville' =>$ville);

        DB::table('contacts')->insert($data);
        return redirect()->route('PageAccueil');

}
  
  //suprimer un Contact.

    public function destroy($id){
      $Con = Contact::find($id); 
      $Con -> delete();

      return redirect('PageAccueil'); 
    }


 //Modifer un Contact.

    public function edit($id){

      $Con = Contact::find($id); 

       return view('EditContact', ['Con' => $Con]); 
}


//And update un Contact.  
    public function update(Request $request, $id){

    $Con = Contact::find($id); 

    $Con->civilite           =     $request-> input('civilite');      
    $Con->prenom             =     $request-> input('prenom');
    $Con->nom                =     $request-> input('nom');
    $Con->fonction           =     $request-> input('fonction');
    $Con->service            =     $request-> input('service');
    $Con->telephone          =     $request-> input('telephone');
    $Con->email              =     $request-> input('email');
    $Con->societe            =     $request-> input('societe');

    $Con->adresseSociete     =     $request-> input('adresseSociete');
    $Con->codePostale        =     $request-> input('codePostale');
    $Con->telephoneSociete   =     $request-> input('telephoneSociete');
    $Con->siteWebSociete     =     $request-> input('siteWebSociete');
    $Con->ville              =     $request-> input('ville');
    
    $Con->save();
        return redirect()->route('PageAccueil');

}
//Visit Contact : 
    public function visit($id){

      $Con = Contact::find($id); 

       return view('VisitContact', ['Con' => $Con]); 
}

}
    

      