 <!DOCTYPE html>
 <html lang="en">
 <head>
    <title>La Formulaire d'un Contact!</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Lato">

	<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/style.css') }}">
 </head>
 <body>
 	<div class="container">
 		
 			 
 		<div class="heading"> <h2>Formulaire de Contact</h2>   </div>
 			<div class="divider"></div>
 		<div class="row">
 			<div class="col-lg-12 col-lg-offset=1">
 				<form id="contact-form" method="post" action="{{url('/ModifierContact/'.$Con->id)}}" role="form" enctype="multipart/form-data" >
 					 <input type="hidden" name="_method" value="PUT">


                               {{ csrf_field() }}
                  
 					

 					<div class="row">

 						<div class="col-md-12">
 							<label for="civilite">Civilité :<span class="blue"> *</span></label>
 							<input type="text" id="civilite" name="civilite" class="form-control" placeholder="Votre Ville" value="{{$Con->civilite}}"> 
 					
 						</div>						

 						<div class="col-md-6">
 							<label for="prenom">Prénom :<span class="blue"> *</span></label>
 							<input type="text" id="prenom" name="prenom" class="form-control" placeholder="Votre Prénom" value="{{$Con->prenom}}">
 						
 						</div>

 						<div class="col-md-6">
 							<label for="nom">Nom :<span class="blue"> *</span></label>
 							<input type="text" id="nom" name="nom" class="form-control" placeholder="Votre Nom" value="{{$Con->nom}}">
 					
 						</div>

 						<div class="col-md-6">
 							<label for="fonction">Fonction :<span class="blue"> *</span></label>
 							<input type="text" id="fonction" name="fonction" class="form-control" placeholder="Votre Fonction" value="{{$Con->fonction}}">
 						
 						</div>


 						<div class="col-md-6">
 							<label for="service">Service :<span class="blue"> *</span></label>
 							<input type="text" id="service" name="service" class="form-control" placeholder="Votre Service" value="{{$Con->service}}">
 						
 						</div>


 						<div class="col-md-6">
 							<label for="telephone">Téléphone :<span class="blue"> *</span></label>
 							<input type="text" id="telephone" name="telephone" class="form-control" placeholder="Votre Téléphone" value="{{$Con->telephone}}">
 						
 						</div>

 						<div class="col-md-6">
 							<label for="email">Email :<span class="blue"> *</span></label>
 							<input type="text" id="email" name="email" class="form-control" placeholder="Votre Email" value="{{$Con->email}}">
 			
 						</div>

 						<div class="col-md-6">
 							<label for="societe">Societé :<span class="blue"> *</span></label>
 							<input type="text" id="societe" name="societe" class="form-control" placeholder="Votre Societé" value="{{$Con->societe}}">
 					
 						</div>




 						<div class="col-md-6">
 							<label for="adresseSociete">Adresse de Societé :<span class="blue"> *</span></label>
 							<input type="text" id="adresseSociete" name="adresseSociete" class="form-control" placeholder="Adresse de societé" value="{{$Con->adresseSociete}}">
 					
 						</div>


 						<div class="col-md-6">
 							<label for="codePostale">Code Postale :<span class="blue"> *</span></label>
 							<input type="text" id="codePostale" name="codePostale" class="form-control" placeholder="Code postale" value="{{$Con->codePostale}}">
 					
 						</div>



 						<div class="col-md-6">
 							<label for="telephoneSociete">Téléphone Societé :<span class="blue"> *</span></label>
 							<input type="text" id="telephoneSociete" name="telephoneSociete" class="form-control" placeholder="Le téléphone du societé" value="{{$Con->telephoneSociete}}">
 						
 						</div>



 						<div class="col-md-6">
 							<label for="siteWebSociete">Site web de Societé :<span class="blue"> *</span></label>
 							<input type="text" id="siteWebSociete" name="siteWebSociete" class="form-control" placeholder="Site web de societé" value="{{$Con->siteWebSociete}}">
 					
 						</div>



 						<div class="col-md-6">
 							<label for="ville">Ville :<span class="blue"> *</span></label>
 							<input type="text" id="ville" name="ville" class="form-control" placeholder="Votre Ville" value="{{$Con->ville}}">
 						
 						</div>

 						<div class="col-md-12">
 							<p class="blue"> <strong>* Ces informations sont requises</strong>  </p>
 						</div>

 						<div class="col-md-12">
 							<button type="submit" class="button1" value="submit">Envoyer </button>
 							
 						</div>
 					</div>

 				
 				</form>
 			</div>
 		</div>
 	</div>
 </body>
 </html>