<!DOCTYPE html>
<html lang="en">
<head>
	<title>Page d'accueil</title>
	 <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Lato">
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/style1.css') }}">

	<script src="https://kit.fontawesome.com/984dd644b9.js" crossorigin="anonymous"></script>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
	
  <div class="container">
    	<div class="heading"> <h1>Liste des contacts</h1></div>
    	<div class="divider"></div>
    	
    	<div>
    		<button type="button" onclick="location.href='PageAccueil/AjouterContact'" class="button2" ><span><i class="fas fa-plus-square"></i></span>  | Ajouter un Contact   </button>  
    	</div>
    	<div>
    		<form method="get" action="{{url('search')}}" >
    			<label class="lbl">Rechercher</label>
    		<input type="search" placeholder="search contact" name="rechercher" class="rech">
    		<button type="submit" ><span><i class="fas fa-search"></i></span> Search</button>
    		</form>

 
    	</div>

    	<div class="row">
    		<div class="col-lg-12 col-lg-offset=1">
    			<form id="accueil" action="" method="get">
    				<div class="row">
               <table class="table" >
                <thead>
                <tr class="color">
                 <th>Civilité</th>
    					   <th>Prénom</th>
 						     <th>Nom</th>
    					   <th>Téléphone</th>
    					   <th>E-mail</th>
    					   <th>Societé</th>
    					   <th>Ville</th>
    					   <th class="bars"><i class="fas fa-bars"></i></th>
  						  </tr>
  						 </thead>

  						 <tbody>
  						 	@foreach ($LesContacts as $contact)
  						 	<tr>
  						 		<td>{{$contact -> civilite }}</td>
  						 		<td>{{$contact -> prenom}}</td>
  						 		<td>{{$contact -> nom}}</td>
  						 		<td>{{$contact -> telephone}}</td>
  						 		<td>{{$contact -> email}}</td>
  						 		<td>{{$contact -> societe}}</td>
  						 		<td>{{$contact -> ville}}</td>
                  <td>
<!--delete -->
                   <a style="padding-left:2px;" href="{{ url('PageAccueil/'.$contact->id) }}" method="get"><i class="fas fa-trash-alt"></i></a>

                   {{csrf_field() }}
                   {{method_field('DELETE') }}
<!--update -->
                   <a style="padding-left:2px;" href="{{url('/PageAccueil/ModifierContact/'.$contact->id)}}"><i class="fas fa-pen"></i></a> 
<!--view -->     
                   <a style="padding-left:2px;" href="{{url('/PageAccueil/VisitContact/'.$contact->id)}}"><i class="fas fa-eye"></i></a>
<!--AddContact -->
                   <a style="padding-left:2px;" href="PageAccueil/AjouterContact"><i class="fab fa-creative-commons-by"></i></a>
                 </td>
  						 		 @endforeach 
  						 	</tr>
  						 </tbody>
				    </table>

         
    			   </div>

    			</form>
           {{ $LesContacts->links() }}
    		</div>
    	</div>
    </div>

</body>
</html>
