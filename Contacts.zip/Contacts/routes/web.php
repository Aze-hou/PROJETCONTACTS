<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group whi

ch
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return view('welcome');
});



//La page d'accueil de projet.
Route::get('/PageAccueil','App\Http\Controllers\ContactController@pageAccueil');

//Formulaire d'ajout un neauveau contact
Route::get('/PageAccueil/AjouterContact','App\Http\Controllers\ContactController@AjoutContact');


//Recherche d'un contact.
Route::get('/search','App\Http\Controllers\ContactController@search');


//Ajouter contact dans la base de donnée.
 Route::post('/submitData','App\Http\Controllers\ContactController@submitData');
 
 //Pour retourner au page d'accueil
 Route::get('/PageAccueil','App\Http\Controllers\ContactController@PageAccueil')->name('PageAccueil');


// suprimer un Contact: 
 Route::get('/PageAccueil/{id}','App\Http\Controllers\ContactController@destroy');

 //Modifier(edit) Contact :

 Route::get('/PageAccueil/ModifierContact/{id}','App\Http\Controllers\ContactController@edit');

//Update Contact :
 Route::put('/ModifierContact/{id}','App\Http\Controllers\ContactController@update');

//Visit Contact : 
 Route::get('/PageAccueil/VisitContact/{id}','App\Http\Controllers\ContactController@visit');    
 


