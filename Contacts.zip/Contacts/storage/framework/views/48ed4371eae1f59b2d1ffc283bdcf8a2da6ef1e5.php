<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<form>
		<h1>Liste des contacts</h1>
    <hr>

    

	<table BORDER="1" >

	
    <tr>
		<td>Civilite</td>
		<td>Prénom</td>
		<td>Nom</td>
		<td>Telephone</td>
		<td>Email</td>
		<td>Societe</td>
		<td>Ville</td>
	</tr>



	<ul>

		<?php $__currentLoopData = $LesContacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
			<li><?php echo e($contact -> civilite); ?> </li>
		    <li><?php echo e($contact -> prenom); ?></li>
			<li><?php echo e($contact -> nom); ?></li> 
			<li><?php echo e($contact -> telephone); ?></li>
			<li><?php echo e($contact -> email); ?></li> 
			<li><?php echo e($contact -> societe); ?></li> 
			<li><?php echo e($contact -> ville); ?></li> 

			<hr>	
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
	
	</ul>
	</table>
	</form>




</body>
</html><?php /**PATH C:\wamp64\www\Contacts\resources\views/ListeContact.blade.php ENDPATH**/ ?>