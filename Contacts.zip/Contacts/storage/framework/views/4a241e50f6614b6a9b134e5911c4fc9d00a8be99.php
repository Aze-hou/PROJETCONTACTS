 <!DOCTYPE html>
 <html lang="en">
 <head>
    <title>La Formulaire d'un Contact!</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Lato">

	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
	<script src="https://kit.fontawesome.com/984dd644b9.js" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
 </head>
 <body>
 	<div class="container">
 		<div class="heading"> <h1> <?php echo $Con->prenom; ?> &nbsp <?php echo $Con->nom; ?> </h1> 
 			<div class="divider"></div>
 		  </div>

 			
<!--Identité du Contact -->
 	<section class="child">
    <form id="contact-form" method="post" action="" role="form" enctype="multipart/form-data">

                               <?php echo e(csrf_field()); ?>                 
          <div class="row">
            <h3>&nbsp &nbsp Identité du Contact</h3>
            <div class="col-md-12">
              <label for="civilite">Civilité </label>
              <input type="text" id="civilite" name="civilite" class="form-control" placeholder="Votre Ville" value="<?php echo e($Con->civilite); ?>" readonly="civilite"> 
              
            </div>            

            <div class="col-md-6">
              <label for="prenom">Prénom </label>
              <input type="text" id="prenom" name="prenom" class="form-control" placeholder="Votre Prénom" value="<?php echo e($Con->prenom); ?>" readonly="prenom">
          
            </div>

            <div class="col-md-6">
              <label for="nom">Nom </label>
              <input type="text" id="nom" name="nom" class="form-control" placeholder="Votre Nom" value="<?php echo e($Con->nom); ?>" readonly="nom">
            
            </div>

            <div class="col-md-6">
              <label for="fonction">Fonction </label>
              <input type="text" id="fonction" name="fonction" class="form-control" placeholder="Votre Fonction" value="<?php echo e($Con->fonction); ?>" readonly="fonction">
              
            </div>


            <div class="col-md-6">
              <label for="service">Service </label>
              <input type="text" id="service" name="service" class="form-control" placeholder="Votre Service" value="<?php echo e($Con->service); ?>" readonly="service">
              
            </div>

            <div class="col-md-12">
              <div class="inputWithIcon">
             <label for="email">E-mail </label>
              <input type="text" id="email" name="email" class="form-control" placeholder="Votre Email" value="<?php echo e($Con->email); ?>" readonly="email"> 
              <i class="fa fa-envelope icon" aria-hidden="true"></i>   
              </div>
            </div>
            
            <div class="col-md-6">
              <label for="telephone">Téléphone mobile </label>
              <input type="text" id="phone" name="telephone" class="form-control" placeholder="Votre Téléphone" value="<?php echo e($Con->telephone); ?>" readonly="telephone">     
            </div>
            
          </div>
          <span class="col-md-4"></span>

    </form>

  </section>


  <!--Societé -->
  <section class="child">       
      <form id="contact-form" method="post" action="" role="form" enctype="multipart/form-data">
                               <?php echo e(csrf_field()); ?>

                               <h3>Societé</h3>
          <div class="row">
            <div class="col-md-12">
              <label for="societe">Nom societé </label>
              <input type="text" id="societe" name="societe" class="form-control" placeholder="Votre Societé" value="<?php echo e($Con->societe); ?>" readonly="societe">             
            </div>
             <div class="col-md-12">
              <label for="adresseSociete">Adresse </label>
              
              <input style="width:500px; height:173px;"  type="text" id="adresseSociete" name="adresseSociete" class="form-control" placeholder="adresse Societé" value="<?php echo e($Con->adresseSociete); ?>" readonly="adresseSociete"> 

        
            </div>
            <div class="col-md-4">
              <label for="codePostale">Code postale </label>
              <input type="text" id="codePostale" name="codePostale" class="form-control" placeholder="Code postale" value="<?php echo e($Con->codePostale); ?>" readonly="codePostale"> 

            </div>

           <div class="col-md-8">
              <label for="ville">Ville </label>
              <input type="text" id="ville" name="ville" class="form-control" placeholder="Votre Ville" value="<?php echo e($Con->ville); ?>" readonly="ville">               
            </div>


            <div class="col-md-4">
              <label for="telephoneSociete">Téléphone </label>
              <input type="text" id="telephoneSociete" name="telephoneSociete" class="form-control" placeholder="Le téléphone du societé" value="<?php echo e($Con->telephoneSociete); ?>" readonly="telephoneSociete">
            </div>

            <div class="col-md-8">
              <label for="siteWebSociete">Site web </label>
              <input type="text" id="siteWebSociete" name="siteWebSociete" class="form-control" placeholder="Site web de societé" value="<?php echo e($Con->siteWebSociete); ?>" readonly="siteWebSociete">
            </div>
            
          </div>
          
        </form>
    </section>
    <span class="col-md-4"></span>
           <div class="row">
                            <div class="form-group col-md-3" >
                            <a href="<?php echo e(url('/PageAccueil/ModifierContact/'.$Con->id)); ?>" class="btn btn-primary"><i class="fas fa-pen"></i> | Modifier</a>  </div>

                   <div class="form-group col-md-6">                      
                            <a href="<?php echo e(url('/PageAccueil')); ?>" class="btn btn-secondary" ><i class="fas fa-table"></i> | Retour à la liste des contacts</a>
                   </div>
                    </div>  
 			
 	
 	</div>
 </body>
 </html><?php /**PATH C:\wamp64\www\Contacts\resources\views/VisitContact.blade.php ENDPATH**/ ?>