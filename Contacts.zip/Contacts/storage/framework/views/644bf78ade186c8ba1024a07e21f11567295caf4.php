<!DOCTYPE html>
<html lang="en">
<head>
	<title>Page d'accueil</title>
	 <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Lato">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style1.css')); ?>">

	<script src="https://kit.fontawesome.com/984dd644b9.js" crossorigin="anonymous"></script>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
	
  <div class="container">
    	<div class="heading"> <h1>Liste des contacts</h1></div>
    	<div class="divider"></div>
    	
    	<div>
    		<button type="button" onclick="location.href='PageAccueil/AjouterContact'" class="button2" ><span><i class="fas fa-plus-square"></i></span>  | Ajouter un Contact   </button>  
    	</div>
    	<div>
    		<form method="get" action="<?php echo e(url('search')); ?>" >
    			<label class="lbl">Rechercher</label>
    		<input type="search" placeholder="search contact" name="rechercher" class="rech">
    		<button type="submit" ><span><i class="fas fa-search"></i></span> Search</button>
    		</form>

 
    	</div>

    	<div class="row">
    		<div class="col-lg-12 col-lg-offset=1">
    			<form id="accueil" action="" method="get">
    				<div class="row">
               <table class="table" >
                <thead>
                <tr class="color">
                 <th>Civilité</th>
    					   <th>Prénom</th>
 						     <th>Nom</th>
    					   <th>Téléphone</th>
    					   <th>E-mail</th>
    					   <th>Societé</th>
    					   <th>Ville</th>
    					   <th class="bars"><i class="fas fa-bars"></i></th>
  						  </tr>
  						 </thead>

  						 <tbody>
  						 	<?php $__currentLoopData = $LesContacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  						 	<tr>
  						 		<td><?php echo e($contact -> civilite); ?></td>
  						 		<td><?php echo e($contact -> prenom); ?></td>
  						 		<td><?php echo e($contact -> nom); ?></td>
  						 		<td><?php echo e($contact -> telephone); ?></td>
  						 		<td><?php echo e($contact -> email); ?></td>
  						 		<td><?php echo e($contact -> societe); ?></td>
  						 		<td><?php echo e($contact -> ville); ?></td>
                  <td>
<!--delete -->
                   <a style="padding-left:2px;" href="<?php echo e(url('PageAccueil/'.$contact->id)); ?>" method="get"><i class="fas fa-trash-alt"></i></a>

                   <?php echo e(csrf_field()); ?>

                   <?php echo e(method_field('DELETE')); ?>

<!--update -->
                   <a style="padding-left:2px;" href="<?php echo e(url('/PageAccueil/ModifierContact/'.$contact->id)); ?>"><i class="fas fa-pen"></i></a> 
<!--view -->     
                   <a style="padding-left:2px;" href="<?php echo e(url('/PageAccueil/VisitContact/'.$contact->id)); ?>"><i class="fas fa-eye"></i></a>
<!--AddContact -->
                   <a style="padding-left:2px;" href="PageAccueil/AjouterContact"><i class="fab fa-creative-commons-by"></i></a>
                 </td>
  						 		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  						 	</tr>
  						 </tbody>
				    </table>

         
    			   </div>

    			</form>
           <?php echo e($LesContacts->links()); ?>

    		</div>
    	</div>
    </div>

</body>
</html>
<?php /**PATH C:\wamp64\www\Contacts\resources\views/PageAccueil.blade.php ENDPATH**/ ?>